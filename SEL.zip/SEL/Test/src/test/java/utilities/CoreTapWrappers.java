package utilities;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.relevantcodes.extentreports.ExtentTest;

import cucumber.api.Scenario;
import cucumber.api.java.Before;

public class CoreTapWrappers extends GenericWrapper {

	public String browserName;
	public String dataSheetName;
	public String testcaseSheetName;
	public Scenario scenario;
	public ConfigFileReader config = new ConfigFileReader();
	
	public static HashMap<String, String> excelHashMapValues = new HashMap<String, String>();

	
	@BeforeSuite
	public void beforeSuite(){
		startResult();
	}

	
		
	@AfterSuite
	public void afterSuite(){
		endResult();
	}

	
}
