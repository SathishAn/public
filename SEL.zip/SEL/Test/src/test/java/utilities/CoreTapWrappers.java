package utilities;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.relevantcodes.extentreports.ExtentTest;

import cucumber.api.Scenario;
import cucumber.api.java.Before;

public class CoreTapWrappers extends GenericWrapper {

	public String browserName;
	public String dataSheetName;
	public String testcaseSheetName;
	public Scenario scenario;
	

	
	@BeforeSuite
	public void beforeSuite(){
		startResult();
	}

	@BeforeTest
	public void beforeTest(){
		//loadObjects();
		
	}
	
	
	@BeforeMethod
	public void beforeMethod(){
		
		category = "smoke";
		authors = "Sathish";
		test = startTestCase("Sample", "Sample");
		test.assignCategory(category);
		test.assignAuthor(authors);
		String url= "https://www.toolsqa.com/automation-practice-form/";
		invokeApp("Chrome", url);
		
	}
		
	@AfterSuite
	public void afterSuite(){
		endResult();
	}

	@AfterTest
	public void afterTest(){
		//unloadObjects();
	}
	
	@AfterMethod
	public void afterMethod(){
		endTestcase();
		closeBrowser();
		
	}
}
