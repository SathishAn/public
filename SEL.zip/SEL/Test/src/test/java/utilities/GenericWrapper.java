package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class GenericWrapper extends Reporter implements Wrapper{
	public static WebDriver driver;
	
	
	public GenericWrapper(WebDriver driver, ExtentTest test) {
        this.driver = driver;
        this.test=test;
        
   }
	
	public GenericWrapper() {
		
		
	}
	
		
	@Override
	public void invokeApp(String browser, String Url) {
		
		// TODO Auto-generated method stub
		System.out.println("invokeapp");
		try {
			if(browser.equalsIgnoreCase("Chrome")){
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				driver=new ChromeDriver();
			}
			else{
				System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
				driver=new FirefoxDriver();
			}
			
			driver.get(Url);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			reportStep("The browser "+browser+" launched successfully.", "PASS");
			System.out.println("The browser "+browser+" launched successfully.");
		} catch (WebDriverException e) {
			reportStep("The browser "+browser+" launched successfully.", "PASS", false);
			System.out.println("The Browser is unexpectedly closed");
		}finally{
			captureScreen();
		}
		
	
	}

	@Override
	public void enterInputText(By by, String data, String fieldName) {
		// TODO Auto-generated method stub
		try {
			driver.findElement(by).clear();
			driver.findElement(by).sendKeys(data);
			reportStep("The Text field "+fieldName+" is entered with text "+data+" successfully.", "PASS");
			System.out.println("The Text field '"+fieldName+"' is entered with text "+data+" successfully.");
		} catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
			reportStep("The element "+fieldName+" is not present in the application", "FAIL");
			System.out.println("The element '"+fieldName+" is not present in the application");
		}catch (WebDriverException e) {
			reportStep("The Browser is unexpectedly closed", "FAIL", false);
			System.out.println("The Browser is unexpectedly closed");
		}finally{
			captureScreen();
		}
		
	}
	
	public void enterInputText(WebElement element, String data, String fieldName) {
		// TODO Auto-generated method stub
		try {
			element.clear();
			element.sendKeys(data);
			reportStep("The Text field "+fieldName+" is entered with text "+data+" successfully.", "PASS");
			System.out.println("The Text field '"+fieldName+"' is entered with text "+data+" successfully.");
		} catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
			reportStep("The element "+fieldName+" is not present in the application", "FAIL");
			System.out.println("The element '"+fieldName+" is not present in the application");
		}catch (WebDriverException e) {
			reportStep("The Browser is unexpectedly closed", "FAIL", false);
			System.out.println("The Browser is unexpectedly closed");
		}finally{
			captureScreen();
		}
		
	}
	
	

	@Override
	public void verifyTitle(String title) {
		// TODO Auto-generated method stub
		String appTitle = driver.getTitle();
		if(appTitle.equals(title)){
			reportStep( "Title '" + title + "' is verified successfully.", "PASS");
			
		}else{
			reportStep("Given title '" + title + "' is not matched", "FAIL");
		}
	}

	@Override
	public void verifyText(By by, String text) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void verifyTextContains(By by, String text) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void webElementClick(By by, String fieldName) {
		// TODO Auto-generated method stub
		try {
			
			driver.findElement(by).click();
			reportStep("The element with id: "+fieldName+" is clicked.", "PASS");
		} catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
			reportStep("The element with id: "+fieldName+" could not be clicked.", "FAIL");
		}
		
		
	}

	@Override
	public String getTextWebElement(By by) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void selectVisibileText(By by, String value) {
		// TODO Auto-generated method stub
		try{
			new Select(driver.findElement(by)).selectByVisibleText(value);;
			reportStep("The element with id: "+by+" is selected with value :"+value, "PASS");
		} catch (Exception e) {
			reportStep("The value: "+value+" could not be selected.", "FAIL");
		}
		
	}

	@Override
	public void selectByValue(By by, String value) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void selectIndexById(By by, int value) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void switchToLastWindow() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void switchToParentWindow() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void acceptAlert() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void captureScreen() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void closeBrowser() {
		// TODO Auto-generated method stub
		driver.close();
		
	}

	@Override
	public void closeAllBrowsers() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void webElementWait(By by) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public long takeSnap() {
		// TODO Auto-generated method stub
		long number = (long) Math.floor(Math.random() * 900000000L) + 10000000L; 
		try {
			FileUtils.copyFile(((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE) , new File("./reports/images/"+number+".jpg"));
		} catch (WebDriverException e) {
			reportStep("The browser has been closed.", "FAIL");
		} catch (IOException e) {
			reportStep("The snapshot could not be taken", "WARN");
		}
		return number;
		
	}
	
	

}
