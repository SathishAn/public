package Test.Test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import pages.DemoPage;
import utilities.CoreTapWrappers;

public class NewTest extends CoreTapWrappers{
	
	
	@BeforeClass
	public void setData() {
		testCaseName="Login";
		testDescription="Login To Opentaps";
		testcaseSheetName= "Sheet1";
		browserName="chrome";
		dataSheetName="TC001";
		category="Smoke";
		authors="Babu";
	}	
  @Test
  public void f() {
	  DemoPage obj = new DemoPage(driver, test);
	  obj.enterFirstName("Sathish");
  }
}
