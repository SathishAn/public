package Test.Test;

import org.testng.annotations.Test;

public class NewTest2 {
  @Test
  public void f() {
	  System.out.println("This is TestNG2");
  }
}
