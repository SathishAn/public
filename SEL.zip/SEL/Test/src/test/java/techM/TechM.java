package techM;


public class TechM {

}
