package stepdefinations;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import pages.DemoPage;
import utilities.CoreTapWrappers;

public class Login_Glue extends CoreTapWrappers {
	
	@Given("^Launch the \"([^\"]*)\" Browser$")
	public void launch_the_Application(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	  invokeApp("Chrome", config.getPropertyValue("url"));
	   
	}  
	
	@When("^I enter the Mandate details in the application$")
	public void i_enter_the_Mandate_details_in_the_application() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		DemoPage dem= new DemoPage(driver, test);
	    dem.enterFirstName(excelHashMapValues.get("FirstName"));
	    dem.enterLastName(excelHashMapValues.get("LastName"));
	   
	}

}
