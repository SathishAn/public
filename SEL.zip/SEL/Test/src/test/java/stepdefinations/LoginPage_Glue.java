package stepdefinations;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;

import com.relevantcodes.extentreports.ExtentTest;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import pages.DemoPage;
import pages.LoginPage;
import utilities.CoreTapWrappers;

public class LoginPage_Glue extends CoreTapWrappers {

	@Given("^Launch the \"([^\"]*)\" Browser$")
	public void launch_the_Application(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("Test");
	   
	   
	}  
	
	@When("^I enter the Mandate details in the application$")
	public void i_enter_the_Mandate_details_in_the_application() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		DemoPage dem= new DemoPage(driver, test);
	    dem.enterFirstName("Sathish A");
	   
	}
	
}
