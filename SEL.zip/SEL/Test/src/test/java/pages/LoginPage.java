package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.relevantcodes.extentreports.ExtentTest;

import cucumber.api.Scenario;
import cucumber.api.java.Before;
import utilities.CoreTapWrappers;

public class LoginPage extends CoreTapWrappers {
	public LoginPage(WebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		 

		/*if(!verifyTitle("Create Lead | opentaps CRM")){
			reportStep("This is not Create Lead Page", "FAIL");
		}*/
		
	}
	
	@Before
	public void getScenario(Scenario scenario) {
		this.scenario=scenario;
		System.out.println(scenario.getName());
		testDescription = scenario.getName();
		testCaseName = scenario.getName();
	}
	
	public LoginPage launchBrowser(String browser, String Url) {
		
		// TODO Auto-generated method stub
				System.out.println("invokeapp");
				try {
					if(browser.equalsIgnoreCase("Chrome")){
						System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
						driver=new ChromeDriver();
					}
					else{
						System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
						driver=new FirefoxDriver();
					}
					
					driver.get(Url);
					driver.manage().window().maximize();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					reportStep("The browser "+browser+" launched successfully.", "PASS");
					System.out.println("The browser "+browser+" launched successfully.");
				} catch (WebDriverException e) {
					reportStep("The browser "+browser+" launched successfully.", "PASS", false);
					System.out.println("The Browser is unexpectedly closed");
				}finally{
					captureScreen();
				}
		return this;
		
	}

}
